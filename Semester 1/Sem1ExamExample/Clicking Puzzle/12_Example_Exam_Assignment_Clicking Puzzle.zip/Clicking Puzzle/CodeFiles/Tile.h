#pragma once

class Tile 
{
public:
	//Tile(const Rectf& dstRect, const std::string& textPath, int nrAnimals );

	//void Draw();
	//void CheckActivation(const Point2f& pos);
	//bool CheckHit(const Point2f& pos);
	//int GetCurrentAnimal( );
	//void Deactivate();
	//void Randomize( );

private: 
};
